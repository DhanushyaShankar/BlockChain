// Replace with the actual deployed contract address
const contractAddress = '0x1d860c04b0354704f9Bd5C4a3d7fA3F9aB6Af238';  // Replace with actual deployed address

// Contract ABI
const contractABI = [
    {
        "inputs": [
            { "internalType": "string", "name": "candidateName", "type": "string" }
        ],
        "name": "addCandidate",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "address", "name": "voter", "type": "address" }
        ],
        "name": "registerVoter",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "uint256", "name": "candidateId", "type": "uint256" }
        ],
        "name": "vote",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getCandidates",
        "outputs": [
            { "internalType": "string[]", "name": "", "type": "string[]" }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getVotes",
        "outputs": [
            { "internalType": "uint256[]", "name": "", "type": "uint256[]" }
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

// Initialize Web3
const web3 = new Web3("http://127.0.0.1:7545");  // Your Ganache URL

// Initialize the contract
const contract = new web3.eth.Contract(contractABI, contractAddress);

// Register Voter
async function registerVoter() {
    const voterAddress = document.getElementById("voterAddress").value;
    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];  // Use the first account from Ganache

        // Call the registerVoter function
        await contract.methods.registerVoter(voterAddress).send({ from: sender, gas: 3000000 });
        alert("Voter registered successfully!");
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Add Candidate
async function addCandidate() {
    const candidateName = document.getElementById("candidateName").value;
    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];  // Use the first account from Ganache

        // Call the addCandidate function
        await contract.methods.addCandidate(candidateName).send({ from: sender, gas: 3000000 });
        alert("Candidate added successfully!");
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Vote for Candidate
async function vote() {
    const candidateId = document.getElementById("candidateId").value;
    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];  // Use the first account from Ganache

        // Call the vote function
        await contract.methods.vote(candidateId).send({ from: sender, gas: 3000000 });
        alert("Vote casted successfully!");
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Get Candidates and Display
async function getCandidates() {
    try {
        const candidates = await contract.methods.getCandidates().call();
        document.getElementById("candidatesList").innerText = "Candidates: " + candidates.join(", ");
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Get Vote Counts and Display
async function getVotes() {
    try {
        const votes = await contract.methods.getVotes().call();
        document.getElementById("votesList").innerText = "Votes: " + votes.join(", ");
    } catch (error) {
        alert("Error: " + error.message);
    }
}
