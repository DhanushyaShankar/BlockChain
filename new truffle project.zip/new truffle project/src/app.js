// Replace with the actual deployed contract address
const contractAddress = '0x0cD4238D2EFBcc0712cE40Be6c3b723c0eaC9229';  // Replace with actual deployed address
const contractABI = [
    {
        "inputs": [
            { "internalType": "string", "name": "location", "type": "string" },
            { "internalType": "uint256", "name": "price", "type": "uint256" }
        ],
        "name": "registerLand",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "uint256", "name": "id", "type": "uint256" },
            { "internalType": "address", "name": "newOwner", "type": "address" }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{ "internalType": "uint256", "name": "id", "type": "uint256" }],
        "name": "getLand",
        "outputs": [
            { "internalType": "string", "name": "", "type": "string" },
            { "internalType": "uint256", "name": "", "type": "uint256" },
            { "internalType": "address", "name": "", "type": "address" }
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

const web3 = new Web3("http://127.0.0.1:7545");  // Your Ganache URL

// Initialize the contract
const contract = new web3.eth.Contract(contractABI, contractAddress);

// Register Land
async function registerLand(location, price) {
    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];  // Use the first account from Ganache

        // Call the registerLand function and send the transaction
        await contract.methods.registerLand(location, price)
            .send({ from: sender, gas: 3000000 })
            .then((receipt) => {
                console.log("Transaction successful:", receipt);
            });
    } catch (error) {
        console.error("Error during registration:", error);
    }
}

// Transfer Ownership
async function transferOwnership() {
    const landId = document.getElementById("landId").value;
    const newOwner = document.getElementById("newOwner").value;

    try {
        const accounts = await web3.eth.getAccounts();
        await contract.methods.transferOwnership(landId, newOwner).send({ from: accounts[0] });
        alert("Ownership transferred successfully!");
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Get Land Details
async function getLandDetails() {
    const landId = document.getElementById("queryLandId").value;

    try {
        const land = await contract.methods.getLand(landId).call();
        document.getElementById("landDetails").innerText = `
            Location: ${land[0]}
            Price: ${land[1]}
            Owner: ${land[2]}
        `;
    } catch (error) {
        alert("Error: " + error.message);
    }
}