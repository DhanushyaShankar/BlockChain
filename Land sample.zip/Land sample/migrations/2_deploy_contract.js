const LandRegistry = artifacts.require("landRegistry");

module.exports = async function (deployer) {
    await deployer.deploy(LandRegistry);
    const instance = await LandRegistry.deployed();
    console.log("Contract Address:", instance.address);
};
