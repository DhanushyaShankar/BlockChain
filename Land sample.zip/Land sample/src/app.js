const contractAddress = '0xbafd9B803F7312AfbAcd649eA376b4a7f8678BA2';  // Replace with actual deployed address
const contractABI = [
    {
        "inputs": [
            { "internalType": "string", "name": "location", "type": "string" },
            { "internalType": "uint256", "name": "price", "type": "uint256" }
        ],
        "name": "registerLand",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "uint256", "name": "id", "type": "uint256" },
            { "internalType": "address", "name": "newOwner", "type": "address" }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{ "internalType": "uint256", "name": "id", "type": "uint256" }],
        "name": "getLand",
        "outputs": [
            { "internalType": "string", "name": "", "type": "string" },
            { "internalType": "uint256", "name": "", "type": "uint256" },
            { "internalType": "address", "name": "", "type": "address" }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "uint256", "name": "id", "type": "uint256" },
            { "internalType": "uint256", "name": "newPrice", "type": "uint256" }
        ],
        "name": "updatePrice",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [{ "internalType": "uint256", "name": "id", "type": "uint256" }],
        "name": "deleteLand",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "string", "name": "_name", "type": "string" },
            { "internalType": "string", "name": "_phoneNumber", "type": "string" },
            { "internalType": "string", "name": "_email", "type": "string" }
        ],
        "name": "addContact",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];

const web3 = new Web3("http://127.0.0.1:7545");  // Your Ganache URL

// Initialize the contract
const contract = new web3.eth.Contract(contractABI, contractAddress);

// Register Land
async function registerLand() {
    const location = document.getElementById("registerLocation").value.trim();
    const price = document.getElementById("registerPrice").value;

    if (!location || isNaN(price) || price <= 0) {
        alert("Invalid location or price. Please ensure all fields are correctly filled.");
        return;
    }

    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];

        await contract.methods.registerLand(location, price)
            .send({ from: sender, gas: 5000000 })
            .then((receipt) => {
                alert("Land registered successfully!");
                console.log("Transaction successful:", receipt);
            });
    } catch (error) {
        console.error("Error during registration:", error);
        alert("Error: " + error.message);
    }
}

// Event listener for form submission
document.addEventListener("DOMContentLoaded", function () {
    const submitButton = document.getElementById('submitButton');
    
    // Check if the submit button exists before attaching event listener
    if (submitButton) {
        submitButton.addEventListener('click', submitContactForm);
    } else {
        console.error("Submit button is not found in the DOM.");
    }
});

// Submit Contact Form
async function submitContactForm() {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();

    if (!name || !phone || !email) {
        alert("Please fill out all the fields.");
        return;
    }

    console.log("Form values:", { name, phone, email });

    try {
        const accounts = await web3.eth.getAccounts();
        console.log("Accounts:", accounts);

        if (!accounts.length) {
            throw new Error("No Ethereum accounts detected.");
        }

        const receipt = await contract.methods.addContact(name, phone, email)
            .send({ from: accounts[0], gas: 500000 });

        console.log("Transaction receipt:", receipt);
        alert("Details saved successfully!");
    } catch (error) {
        console.error("Error during submission:", error);
        alert("Failed to save contact details. Ensure blockchain connection.");
    }
}

// Event listeners for navigation
document.getElementById("navHome").addEventListener("click", () => showSection("homeSection"));
document.getElementById("navAbout").addEventListener("click", () => showSection("aboutSection"));
document.getElementById("navContact").addEventListener("click", () => showSection("contactSection"));
document.getElementById("navRegistry").addEventListener("click", () => showSection("registrySection"));

function showSection(sectionId) {
    document.querySelectorAll(".section").forEach(section => {
        section.style.display = section.id === sectionId ? "block" : "none";
    });
}

showSection('homeSection');
