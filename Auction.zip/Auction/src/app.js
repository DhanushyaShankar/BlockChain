const Web3 = require("web3");

// Initialize Web3
let web3 = new Web3(Web3.givenProvider || "http://localhost:7545");

// Replace with your contract's address and ABI
let contractAddress = "YOUR_CONTRACT_ADDRESS_HERE";
let contractABI = [
    {
        "contractName": "AuctionPlatform",
        "abi": [
          {
            "anonymous": false,
            "inputs": [
              {
                "indexed": false,
                "internalType": "address",
                "name": "winner",
                "type": "address"
              },
              {
                "indexed": false,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
              }
            ],
            "name": "AuctionEnded",
            "type": "event"
          },
          {
            "anonymous": false,
            "inputs": [
              {
                "indexed": false,
                "internalType": "string",
                "name": "itemName",
                "type": "string"
              },
              {
                "indexed": false,
                "internalType": "uint256",
                "name": "startingPrice",
                "type": "uint256"
              },
              {
                "indexed": false,
                "internalType": "uint256",
                "name": "endTime",
                "type": "uint256"
              }
            ],
            "name": "AuctionStarted",
            "type": "event"
          },
          {
            "anonymous": false,
            "inputs": [
              {
                "indexed": true,
                "internalType": "address",
                "name": "bidder",
                "type": "address"
              },
              {
                "indexed": false,
                "internalType": "uint256",
                "name": "bidAmount",
                "type": "uint256"
              }
            ],
            "name": "NewHighestBid",
            "type": "event"
          },
          {
            "inputs": [],
            "name": "auction",
            "outputs": [
              {
                "internalType": "string",
                "name": "itemName",
                "type": "string"
              },
              {
                "internalType": "uint256",
                "name": "startingPrice",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "highestBid",
                "type": "uint256"
              },
              {
                "internalType": "address",
                "name": "highestBidder",
                "type": "address"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "auctionEndTime",
            "outputs": [
              {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "auctionEnded",
            "outputs": [
              {
                "internalType": "bool",
                "name": "",
                "type": "bool"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "auctionOwner",
            "outputs": [
              {
                "internalType": "address",
                "name": "",
                "type": "address"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
          {
            "inputs": [
              {
                "internalType": "address",
                "name": "",
                "type": "address"
              }
            ],
            "name": "pendingReturns",
            "outputs": [
              {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
          {
            "inputs": [
              {
                "internalType": "string",
                "name": "_itemName",
                "type": "string"
              },
              {
                "internalType": "uint256",
                "name": "_startingPrice",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "_durationInMinutes",
                "type": "uint256"
              }
            ],
            "name": "startAuction",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "placeBid",
            "outputs": [],
            "stateMutability": "payable",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "withdraw",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "endAuction",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
          },
          {
            "inputs": [],
            "name": "getAuctionDetails",
            "outputs": [
              {
                "internalType": "string",
                "name": "",
                "type": "string"
              },
              {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
              },
              {
                "internalType": "address",
                "name": "",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
              }
            ],
            "stateMutability": "view",
            "type": "function"
          },
        
        ],
    }
];

// Initialize the contract
const auctionContract = new web3.eth.Contract(contractABI, contractAddress);

// Function to display output in the HTML
function displayOutput(message) {
    document.getElementById("output").innerHTML = message;
}

// Event listener for starting an auction
document.getElementById("startAuction").addEventListener("click", async () => {
    const itemName = document.getElementById("itemName").value;
    const startingPrice = document.getElementById("startingPrice").value;
    const duration = document.getElementById("duration").value;

    if (!itemName || !startingPrice || !duration) {
        displayOutput("Please fill all fields to start an auction.");
        return;
    }

    try {
        const accounts = await web3.eth.getAccounts();
        await auctionContract.methods.startAuction(itemName, startingPrice, duration).send({ from: accounts[0] });
        displayOutput(`Auction started for '${itemName}' with a starting price of ${startingPrice} Wei.`);
    } catch (error) {
        displayOutput(`Error: ${error.message}`);
    }
});

// Event listener for placing a bid
document.getElementById("placeBid").addEventListener("click", async () => {
    const bidAmount = document.getElementById("bidAmount").value;

    if (!bidAmount) {
        displayOutput("Please enter a bid amount.");
        return;
    }

    try {
        const accounts = await web3.eth.getAccounts();
        await auctionContract.methods.placeBid().send({ from: accounts[0], value: bidAmount });
        displayOutput(`Bid of ${bidAmount} Wei placed successfully.`);
    } catch (error) {
        displayOutput(`Error: ${error.message}`);
    }
});

// Event listener for fetching auction details
document.getElementById("getDetails").addEventListener("click", async () => {
    try {
        const details = await auctionContract.methods.getAuctionDetails().call();
        const { 0: itemName, 1: startingPrice, 2: highestBid, 3: highestBidder, 4: auctionEndTime } = details;

        displayOutput(`
            Item Name: ${itemName}<br>
            Starting Price: ${startingPrice} Wei<br>
            Highest Bid: ${highestBid} Wei<br>
            Highest Bidder: ${highestBidder}<br>
            Auction End Time: ${new Date(auctionEndTime * 1000).toLocaleString()}
        `);
    } catch (error) {
        displayOutput(`Error: ${error.message}`);
    }
});
