javascript
const auctionsystem = artifacts.require("auctionsystem");

module.exports = function (deployer) {
  deployer.deploy(auctionsystem);
};
